"""
Würfelt 0 für Kopf oder 1 für Zahl.
"""
import random
import time
import math
import datetime
import os

import random
def muenze_werfen(): return random.randint(0,1)

AVAILABLE_SKILLS = [muenze_werfen]
